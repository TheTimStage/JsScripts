package org.tts.jsscripts.systems;

public final class ScriptManager {

    public static void save(String name, String code) {
    }

    public static void run(String name, String code) {
        ScriptEngine.run(name, code);
    }

    public static void stop(String name) {

        // 1. убираем loop
        ScriptEngine.removeLoop(name);

        // 2. убираем scheduled tasks
        ScriptEngine.removeTasks(name);

        // 3. убираем handlers событий
        ScriptEngine.removeEventHandlers(name);

        // 4. чистим тип
        ScriptEngine.removeScriptType(name);

        System.out.println("[JsScripts] Script '" + name + "' stopped.");
    }

}
