package org.tts.jsscripts.client;

import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents;
import net.minecraft.class_10799;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_408;

public class SctiptsButton {
    private static final int SIZE = 20;
    private static final class_2960 ICON =
            class_2960.method_60655("jsscripts", "textures/gui/icon.png");

    private static int btnX, btnY;

    public static void init() {

        ScreenEvents.AFTER_INIT.register((client, screen, width, height) -> {
            if (!(screen instanceof class_408)) return;

            btnX = width - SIZE - 8;
            btnY = 8;
            ScreenEvents.afterRender(screen).register((scr, ctx, mouseX, mouseY, delta) -> {
                renderButton(ctx, mouseX, mouseY);
            });

            ScreenMouseEvents.afterMouseClick(screen).register((scr, mouseX, mouseY, button) -> {
                if (button == 0 && inside(mouseX, mouseY)) {
                    if (client.field_1724 != null)
                        client.field_1724.field_3944.method_45730("jsscripts gui");
                }
            });
        });
    }

    private static boolean inside(double mx, double my) {
        return mx >= btnX && mx <= btnX + SIZE &&
                my >= btnY && my <= btnY + SIZE;
    }

    private static void renderButton(class_332 ctx, int mouseX, int mouseY) {
        boolean hover = inside(mouseX, mouseY);
        int bg = hover ? 0xFFCCCCCC : 0xFF888888;

        ctx.method_25294(btnX, btnY, btnX + SIZE, btnY + SIZE, bg);
        ctx.method_49601(btnX, btnY, SIZE, SIZE, 0xFF000000);
        ctx.method_25290(
                class_10799.field_56883,
                ICON,
                btnX + 2,
                btnY + 2,
                0f, 0f,
                SIZE - 4,
                SIZE - 4,
                SIZE - 4,
                SIZE - 4
        );


    }
}
