package org.tts.jsscripts.client;

import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import org.tts.jsscripts.networking.JsSNetworkingClient;

public class NewScriptAdd extends class_437 {

    private final String directory;
    private class_342 nameField;

    private int boxX, boxY, boxWidth, boxHeight;

    public NewScriptAdd(String directory) {
        super(class_2561.method_43470("Create New Script"));
        this.directory = directory == null ? "" : directory;
    }

    @Override
    protected void method_25426() {

        this.boxWidth = Math.max(350, (int) (this.field_22789 * 0.40));
        this.boxHeight = Math.max(160, (int) (this.field_22790 * 0.25));

        this.boxX = (this.field_22789 - boxWidth) / 2;
        this.boxY = (this.field_22790 - boxHeight) / 2;

        nameField = new class_342(
                this.field_22793,
                boxX + 20,
                boxY + 50,
                boxWidth - 40,
                20,
                class_2561.method_43470("Script Name")
        );
        nameField.method_1852("new_script.js");
        method_37063(nameField);

        method_37063(class_4185.method_46430(class_2561.method_43470("Create"), btn -> {

            String file = nameField.method_1882().trim();
            if (file.isEmpty()) return;

            if (!file.endsWith(".js"))
                file += ".js";

            String fullPath = directory.isEmpty()
                    ? file
                    : directory + "/" + file;

            JsSNetworkingClient.sendSaveScript(fullPath, "");
            class_310.method_1551().method_1507(new ScriptsScreen(directory));

        }).method_46434(
                boxX + 20,
                boxY + boxHeight - 35,
                boxWidth / 2 - 30,
                20
        ).method_46431());

        method_37063(class_4185.method_46430(class_2561.method_43470("Cancel"), btn -> {
            class_310.method_1551().method_1507(new ScriptsScreen(directory));
        }).method_46434(
                boxX + boxWidth / 2 + 10,
                boxY + boxHeight - 35,
                boxWidth / 2 - 30,
                20
        ).method_46431());
    }

    @Override
    public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {

        ctx.method_25294(0, 0, field_22789, field_22790, 0xCC000000);
        ctx.method_25294(boxX, boxY, boxX + boxWidth, boxY + boxHeight, 0xFF2B2B2B);

        ctx.method_25300(field_22793, "Create New Script",
                field_22789 / 2, boxY + 20, 0xFFFFFF);

        super.method_25394(ctx, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
