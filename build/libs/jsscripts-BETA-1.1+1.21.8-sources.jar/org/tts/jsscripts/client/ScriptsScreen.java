package org.tts.jsscripts.client;

import org.tts.jsscripts.networking.JsSNetworking;
import org.tts.jsscripts.networking.JsSNetworkingClient;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.class_10799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class ScriptsScreen extends class_437 {

    private List<JsSNetworking.ScriptEntry> allEntries = new ArrayList<>();
    private List<JsSNetworking.ScriptEntry> entries = new ArrayList<>();

    private String directory;

    private int boxX, boxY, boxW, boxH;
    private int scroll = 0;
    private final int rowHeight = 36;

    private int hoverIndex = -1;
    private int hoverRowY = 0;

    private final List<class_4185> hoverButtons = new ArrayList<>();

    private class_342 searchField;

    private static final class_2960 ICON_RUN  = class_2960.method_60655("jsscripts", "textures/gui/runn.png");
    private static final class_2960 ICON_STOP = class_2960.method_60655("jsscripts", "textures/gui/stop.png");
    private static final class_2960 ICON_EDIT = class_2960.method_60655("jsscripts", "textures/gui/editt.png");
    private static final class_2960 ICON_DEL  = class_2960.method_60655("jsscripts", "textures/gui/deletee.png");

    private static final int BTN_SIZE = 20;

    public ScriptsScreen(String directory) {
        super(class_2561.method_43470("Scripts"));
        this.directory = directory == null ? "" : directory;
    }

    @Override
    protected void method_25426() {
        boxW = 430;
        boxH = 260;

        boxX = (this.field_22789 - boxW) / 2;
        boxY = (this.field_22790 - boxH) / 2;

        int searchX = boxX + 10;
        int searchY = boxY + 30;
        int searchW = boxW - 20;

        searchField = new class_342(
                this.field_22793,
                searchX, searchY,
                searchW, 18,
                class_2561.method_43470("Search")
        );
        searchField.method_47404(class_2561.method_43470("Search by name..."));
        searchField.method_1863(s -> applyFilter());
        this.method_37063(searchField);

        this.method_37063(
                class_4185.method_46430(class_2561.method_43470("New Script"), b ->
                                class_310.method_1551().method_1507(new NewScriptAdd(directory))
                        )
                        .method_46434(boxX + (boxW - 160) / 2, boxY + boxH - 28, 160, 20)
                        .method_46431()
        );

        JsSNetworkingClient.sendRequestList(directory);
    }

    public void updateEntries(String dir, List<JsSNetworking.ScriptEntry> newEntries) {
        this.directory = dir;
        this.allEntries = newEntries != null ? newEntries : new ArrayList<>();
        applyFilter();
    }

    private void applyFilter() {
        String query = searchField != null ? searchField.method_1882().trim().toLowerCase(Locale.ROOT) : "";
        entries = new ArrayList<>();

        if (query.isEmpty()) entries.addAll(allEntries);
        else {
            for (JsSNetworking.ScriptEntry e : allEntries) {
                String name = e.path();
                int idx = name.lastIndexOf('/');
                if (idx >= 0) name = name.substring(idx + 1);
                if (name.toLowerCase(Locale.ROOT).contains(query)) entries.add(e);
            }
        }

        int listH = boxH - 95;
        int maxScroll = Math.max(0, entries.size() * rowHeight - listH);
        scroll = Math.min(scroll, maxScroll);
        scroll = Math.max(scroll, 0);

        setHoverRow(-1, 0, boxX + 10, boxW - 20);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double scrollX, double scrollY) {
        int listX = boxX + 10;
        int listY = boxY + 55;
        int listW = boxW - 20;
        int listH = boxH - 95;

        if (mouseX < listX || mouseX > listX + listW ||
                mouseY < listY || mouseY > listY + listH)
            return false;

        int contentH = entries.size() * rowHeight;
        int maxScroll = Math.max(0, contentH - listH);

        scroll -= (int) (scrollY * rowHeight);
        scroll = Math.max(0, Math.min(scroll, maxScroll));

        return true;
    }

    @Override
    public boolean method_25402(double mx, double my, int button) {
        if (super.method_25402(mx, my, button)) return true;
        if (button != 0) return false;

        int listX = boxX + 10;
        int listY = boxY + 55;

        int index = (int) ((my - listY + scroll) / rowHeight);
        if (index < 0 || index >= entries.size()) return false;

        JsSNetworking.ScriptEntry e = entries.get(index);

        int rowY = listY + index * rowHeight - scroll;
        if (my < rowY || my > rowY + rowHeight) return false;

        if (e.directory()) {
            class_310.method_1551().method_1507(new ScriptsScreen(e.path()));
            return true;
        }

        return false;
    }

    @Override
    public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {
        ctx.method_25294(0, 0, field_22789, field_22790, 0x88000000);

        ctx.method_25294(boxX, boxY, boxX + boxW, boxY + boxH, 0xFF2B2B2B);
        ctx.method_49601(boxX, boxY, boxW, boxH, 0xFF505050);

        ctx.method_25300(field_22793, "Scripts", field_22789 / 2, boxY + 10, 0xFFFFFFFF);

        int listX = boxX + 10;
        int listY = boxY + 55;
        int listW = boxW - 20;
        int listH = boxH - 95;

        ctx.method_25294(listX, listY, listX + listW, listY + listH, 0xFF1F1F1F);

        renderList(ctx, mouseX, mouseY, listX, listY, listW, listH);

        ctx.method_49601(listX, listY, listW, listH, 0xFF808080);

        super.method_25394(ctx, mouseX, mouseY, delta);

        drawIcons(ctx);
        drawScrollbar(ctx, listX + listW - 6, listY, listH);
    }

    private void renderList(class_332 ctx, int mouseX, int mouseY, int listX, int listY, int listW, int listH) {
        int listBottom = listY + listH;
        int start = Math.max(0, scroll / rowHeight);
        int end = Math.min(entries.size(), start + listH / rowHeight + 4);

        int newHoverIndex = -1;
        int newHoverRowY = 0;

        for (int i = start; i < end; i++) {
            JsSNetworking.ScriptEntry e = entries.get(i);
            int rowY = listY + i * rowHeight - scroll;

            if (rowY < listY || rowY + rowHeight > listBottom) continue;

            boolean hover = mouseX >= listX && mouseX <= listX + listW &&
                    mouseY >= rowY && mouseY <= rowY + rowHeight;

            if (hover) {
                newHoverIndex = i;
                newHoverRowY = rowY;
            }

            ctx.method_25294(listX, rowY, listX + listW, rowY + rowHeight,
                    hover ? 0xFF424242 : 0xFF343434);

            String name = e.path().substring(e.path().lastIndexOf("/") + 1);
            int textY = rowY + (rowHeight - field_22793.field_2000) / 2 + 1;
            ctx.method_51433(field_22793, name, listX + 8, textY, 0xFFFFFFFF, false);
        }

        setHoverRow(newHoverIndex, newHoverRowY, listX, listW);
    }

    private void setHoverRow(int index, int rowY, int listX, int listW) {
        for (class_4185 btn : hoverButtons) method_37066(btn);
        hoverButtons.clear();

        hoverIndex = index;
        hoverRowY = rowY;

        if (index < 0 || index >= entries.size()) return;

        JsSNetworking.ScriptEntry e = entries.get(index);
        if (e.directory()) return;

        int delX = listX + listW - BTN_SIZE - 5;
        int editX = delX - BTN_SIZE - 5;
        int runX = editX - BTN_SIZE - 5;

        boolean running = JsSNetworkingClient.isRunning(e.path());

        class_4185 runStop = class_4185.method_46430(class_2561.method_43473(), b -> {
            if (running) {
                JsSNetworkingClient.sendStopScript(e.path());
            } else {
                JsSNetworkingClient.sendRunScript(e.path());
                class_310.method_1551().method_1507(null);
            }
        }).method_46434(runX, rowY + 8, BTN_SIZE, BTN_SIZE).method_46431();


        class_4185 edit = class_4185.method_46430(class_2561.method_43473(),
                        b -> JsSNetworkingClient.sendOpenEditor(e.path()))
                .method_46434(editX, rowY + 8, BTN_SIZE, BTN_SIZE).method_46431();

        class_4185 del = class_4185.method_46430(class_2561.method_43473(),
                        b -> JsSNetworkingClient.sendDeleteEntry(e.path(), false))
                .method_46434(delX, rowY + 8, BTN_SIZE, BTN_SIZE).method_46431();

        hoverButtons.add(runStop);
        hoverButtons.add(edit);
        hoverButtons.add(del);

        method_37063(runStop);
        method_37063(edit);
        method_37063(del);
    }

    private void drawIcons(class_332 ctx) {
        if (hoverIndex < 0 || hoverIndex >= entries.size()) return;

        JsSNetworking.ScriptEntry e = entries.get(hoverIndex);
        boolean running = JsSNetworkingClient.isRunning(e.path());

        for (int i = 0; i < hoverButtons.size(); i++) {
            class_4185 btn = hoverButtons.get(i);

            class_2960 icon = switch (i) {
                case 0 -> running ? ICON_STOP : ICON_RUN;
                case 1 -> ICON_EDIT;
                case 2 -> ICON_DEL;
                default -> null;
            };
            if (icon == null) continue;

            ctx.method_25290(
                    class_10799.field_56883,
                    icon,
                    btn.method_46426() + 2,
                    btn.method_46427() + 2,
                    0, 0,
                    BTN_SIZE - 4,
                    BTN_SIZE - 4,
                    BTN_SIZE - 4,
                    BTN_SIZE - 4
            );
        }
    }

    private void drawScrollbar(class_332 ctx, int x, int y, int h) {
        int content = entries.size() * rowHeight;
        if (content <= h) return;

        ctx.method_25294(x, y, x + 5, y + h, 0xFF101010);

        float ratio = (float) h / content;
        int barH = Math.max(20, (int) (ratio * h));

        float pos = (float) scroll / (content - h);
        int barY = (int) (pos * (h - barH));

        ctx.method_25294(x + 1, y + barY + 1, x + 4, y + barY + barH - 1, 0xFFCCCCCC);
    }

    public void refreshHover() {
        setHoverRow(hoverIndex, hoverRowY, boxX + 10, boxW - 20);
    }

}
