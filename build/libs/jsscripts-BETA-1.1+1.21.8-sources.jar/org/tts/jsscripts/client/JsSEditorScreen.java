package org.tts.jsscripts.client;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.EvaluatorException;
import org.tts.jsscripts.networking.JsSNetworkingClient;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class JsSEditorScreen extends class_437 {
    private static final int GUTTER_WIDTH = 45;
    private static final int BORDER_SIZE  = 2;
    private static final int LINE_HEIGHT  = 14;

    private static final List<String> KEYWORDS = Arrays.asList(
            "let","var","const","if","else","for","while","switch","case","break",
            "continue","function","return","class","extends","new","try","catch",
            "throw","async","await","true","false","null","undefined",
            "Math","JSON","Object","Array","Number","String","Boolean"
    );

    private List<String> lines = new ArrayList<>();
    private final String filePath;
    private int editorX, editorY, editorW, editorH;
    private int scroll = 0;
    private int caretLine = 0;
    private int caretCol  = 0;

    private static class Suggestion {
        final String name;
        final String signature;
        final String description;
        Suggestion(String name, String signature, String description) {
            this.name = name;
            this.signature = signature;
            this.description = description;
        }
    }

    private final List<Suggestion> allSuggestions = new ArrayList<>();
    private List<Suggestion> visibleSuggestions = new ArrayList<>();
    private boolean suggestionOpen = false;
    private int suggestionIndex = 0;
    private int suggestionX = 0;
    private int suggestionY = 0;
    private String lastErrorMessage = null;
    private int lastErrorLine = -1;
    private int lastErrorColumn = -1;
    private boolean selecting = false;
    private int selStartLine = -1;
    private int selStartCol  = -1;
    private int selEndLine   = -1;
    private int selEndCol    = -1;

    private static class EditorState {
        final List<String> lines;
        final int caretLine, caretCol;

        EditorState(List<String> lines, int cl, int cc) {
            this.lines = new ArrayList<>(lines);
            this.caretLine = cl;
            this.caretCol = cc;
        }
    }
    private final List<EditorState> undoStack = new ArrayList<>();

    public JsSEditorScreen(String path, String content) {
        super(class_2561.method_43470("JS Editor"));
        this.filePath = path;

        if (content != null && !content.isEmpty()) {
            this.lines = new ArrayList<>(Arrays.asList(content.split("\n", -1)));
        } else {
            this.lines.add("");
        }

        initSuggestions();
        recheckSyntax();
    }

    @Override
    protected void method_25426() {
        editorX = 60;
        editorY = 40;
        editorW = field_22789  - 120;
        editorH = field_22790 - 120;

        int btnY = editorY + editorH + 10;
        int btnW = 80;
        int btnH = 20;

        method_37063(
                class_4185.method_46430(class_2561.method_43470("Save"), b -> {
                    JsSNetworkingClient.sendSaveScript(filePath, collectText());
                    class_310.method_1551().method_1507(null);
                }).method_46434(editorX, btnY, btnW, btnH).method_46431()
        );

        method_37063(
                class_4185.method_46430(class_2561.method_43470("Back"), b ->
                        class_310.method_1551().method_1507(null)
                ).method_46434(editorX + btnW + 20, btnY, btnW, btnH).method_46431()
        );
    }

    private String collectText() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < lines.size(); i++) {
            sb.append(lines.get(i));
            if (i < lines.size() - 1) sb.append("\n");
        }
        return sb.toString();
    }

    private void initSuggestions() {
        addSuggestion("let", "let name = value", "Объявление переменной с блочной областью видимости.");
        addSuggestion("const", "const NAME = value", "Константа, которую нельзя переопределить.");
        addSuggestion("var", "var name = value", "Переменная с функциональной областью видимости.");
        addSuggestion("function", "function name(args) {}", "Объявление функции.");
        addSuggestion("class", "class Name {}", "Объявление класса.");
        addSuggestion("async", "async function() {}", "Асинхронная функция.");
        addSuggestion("await", "await expr", "Ожидание Promise.");
        addSuggestion("return", "return value", "Вернуть значение из функции.");
        addSuggestion("if", "if (expr) {}", "Условный оператор.");
        addSuggestion("else", "else {}", "Альтернативная ветка.");
        addSuggestion("for", "for (let i=0;i<...;i++) {}", "Цикл for.");
        addSuggestion("while", "while(expr) {}", "Цикл while.");
        addSuggestion("switch", "switch(x) {}", "Switch-конструкция.");
        addSuggestion("try", "try {} catch(err) {}", "Обработка ошибок.");
        addSuggestion("log", "log(value)", "Вывод в консоль сервера.");
        addSuggestion("scriptType", "scriptType(\"once\" | \"loop\")", "Тип скрипта: одно выполнение или работа в тиках.");
        addSuggestion("scriptEnd", "scriptEnd()", "Принудительно завершает выполнение текущего скрипта.");
        addSuggestion("on", "on(event, (args)=>{})", "Подписка на событие ScriptAPI.");
        addSuggestion("onLoop", "onLoop(()=>{})", "Функция, вызываемая каждый тик, только если scriptType('loop').");
        addSuggestion("wait", "wait(ticks, ()=>{})", "Отложенный вызов функции через N тиков.");
        addSuggestion("delay", "delay(ticks, ()=>{})", "Alias wait().");
        addSuggestion("repeat", "repeat(count, i=>{})", "Выполнить функцию N раз с индексом i.");
        addSuggestion("every", "every(ticks, ()=>{})", "Вызывать функцию каждые N тиков.");
        addSuggestion("serverStart", "\"serverStart\"", "Событие: сервер запущен.");
        addSuggestion("serverTick", "\"serverTick\"", "Событие: каждый тик сервера.");
        addSuggestion("playerJoin", "\"playerJoin\"", "Игрок зашёл.");
        addSuggestion("playerLeave", "\"playerLeave\"", "Игрок вышел.");
        addSuggestion("playerTick", "\"playerTick\"", "Каждый тик по игроку.");
        addSuggestion("chatMessage", "\"chatMessage\"", "Сообщение: (msg, player).");
        addSuggestion("blockBreak", "\"blockBreak\"", "Игрок сломал блок.");
        addSuggestion("blockPlace", "\"blockPlace\"", "Игрок кликнул по блоку.");
        addSuggestion("msg", "msg(player, text)", "Сообщение игроку.");
        addSuggestion("sendMessage", "sendMessage(player, msg)", "Синоним msg().");
        addSuggestion("actionbar", "actionbar(player, text)", "Сообщение в actionbar.");
        addSuggestion("title", "title(player, text)", "Большой заголовок на экране.");
        addSuggestion("subtitle", "subtitle(player, text)", "Подзаголовок.");
        addSuggestion("fullTitle", "fullTitle(player, title, subtitle, fadeIn, stay, fadeOut)", "Полный титр с таймингами.");
        addSuggestion("tp", "tp(player, x,y,z)", "Телепортировать игрока.");
        addSuggestion("give", "give(player, itemId)", "Выдать предмет игроку.");
        addSuggestion("playSound", "playSound(player, id, volume, pitch)", "Проиграть звук игроку.");
        addSuggestion("playSoundAt", "playSoundAt(world, x,y,z, id [,volume,pitch])", "Проиграть звук по координатам.");
        addSuggestion("World", "World", "Глобальный объект мира.");
        addSuggestion("World.overworld", "World.overworld()", "Обычный мир.");
        addSuggestion("World.nether", "World.nether()", "Незер.");
        addSuggestion("World.end", "World.end()", "Энд.");
        addSuggestion("World.setBlock", "World.setBlock(world,x,y,z,blockId)", "Поставить блок.");
        addSuggestion("World.particle", "World.particle(world,id,x,y,z,dx,dy,dz,speed,count)", "Показать частицы.");
        addSuggestion("runCommand", "runCommand(cmd)", "Выполнить команду от имени сервера.");
        addSuggestion("runCommandAs", "runCommandAs(player, cmd)", "Команда от лица игрока.");
    }

    private void addSuggestion(String name, String signature, String desc) {
        allSuggestions.add(new Suggestion(name, signature, desc));
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horiz, double vert) {
        int maxScroll = Math.max(0, lines.size() * LINE_HEIGHT - editorH);
        scroll -= (int) (vert * 20);
        if (scroll < 0) scroll = 0;
        if (scroll > maxScroll) scroll = maxScroll;
        return true;
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (button != 0) return false;

        if (mouseX < editorX || mouseX > editorX + editorW) return false;
        if (mouseY < editorY || mouseY > editorY + editorH) return false;

        int line = (int)((mouseY - editorY + scroll) / LINE_HEIGHT);
        line = Math.max(0, Math.min(lines.size() - 1, line));

        String l = lines.get(line);
        int col = 0;
        int px = editorX + 6;

        for (int i = 0; i <= l.length(); i++) {
            int w = field_22793.method_1727(l.substring(0, i));
            if (px + w >= mouseX) {
                col = i;
                break;
            }
            col = i;
        }

        caretLine = line;
        caretCol = col;

        selecting = true;
        selStartLine = line;
        selStartCol = col;
        selEndLine = line;
        selEndCol = col;

        return true;
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double dx, double dy) {
        if (!selecting) return false;

        int line = (int)((mouseY - editorY + scroll) / LINE_HEIGHT);
        line = Math.max(0, Math.min(lines.size() - 1, line));

        String l = lines.get(line);
        int col = 0;
        int px = editorX + 6;

        for (int i = 0; i <= l.length(); i++) {
            int w = field_22793.method_1727(l.substring(0, i));
            if (px + w >= mouseX) {
                col = i;
                break;
            }
            col = i;
        }

        selEndLine = line;
        selEndCol = col;

        caretLine = line;
        caretCol = col;

        return true;
    }



    @Override
    public boolean method_25400(char chr, int modifiers) {
        if (chr == '\r' || chr == '\n') {
            return true;
        }

        if (chr == '}') {
            handleClosingBrace();
            recheckSyntax();
            updateSuggestionsAuto();
            return true;
        }

        if (chr >= 32 && chr != 127) {
            if (autoPair(chr)) {
                recheckSyntax();
                updateSuggestionsAuto();
                return true;
            }

            insertText(String.valueOf(chr));
            updateSuggestionsAuto();
        }

        return true;
    }

    @Override
    public boolean method_25404(int key, int scan, int mods) {
        if (suggestionOpen) {
            if (key == 265) {
                if (!visibleSuggestions.isEmpty()) {
                    suggestionIndex = Math.max(0, suggestionIndex - 1);
                }
                return true;
            }

            if (key == 264) {
                if (!visibleSuggestions.isEmpty()) {
                    suggestionIndex = Math.min(visibleSuggestions.size() - 1, suggestionIndex + 1);
                }
                return true;
            }

            if (key == 257 || key == 258) {
                acceptSuggestion();
                return true;
            }

            if (key == 256) {
                suggestionOpen = false;
                return true;
            }
        }

        if (key == 257) { splitLineWithAutoIndent(); return true; }
        if (key == 259) { backspace(); return true; }
        if (key == 261) { delete(); return true; }
        if (key == 263) { moveLeft(); return true; }
        if (key == 262) { moveRight(); return true; }
        if (key == 265) { moveUp(); return true; }
        if (key == 264) { moveDown(); return true; }
        if (key == 258) {
            insertText("    ");
            updateSuggestionsAuto();
            return true;
        }

        if ((mods & 2) != 0) {
            if (key == 67 && hasSelection()) {
                class_310.method_1551().field_1774.method_1455(getSelectedText());
                return true;
            }

            if (key == 86) {
                saveUndo();
                insertText(class_310.method_1551().field_1774.method_1460());
                return true;
            }

            if (key == 90) {
                undo();
                return true;
            }
        }


        return super.method_25404(key, scan, mods);
    }

    private String getSelectedText() {
        if (!hasSelection()) return "";

        StringBuilder sb = new StringBuilder();
        int a = Math.min(selStartLine, selEndLine);
        int b = Math.max(selStartLine, selEndLine);

        for (int i = a; i <= b; i++) {
            String l = lines.get(i);
            int s = (i == selStartLine) ? selStartCol : 0;
            int e = (i == selEndLine) ? selEndCol : l.length();
            sb.append(l, s, e);
            if (i < b) sb.append("\n");
        }
        return sb.toString();
    }

    private void saveUndo() {
        undoStack.add(new EditorState(lines, caretLine, caretCol));
        if (undoStack.size() > 100) undoStack.remove(0);
    }

    private void undo() {
        if (undoStack.isEmpty()) return;
        EditorState s = undoStack.remove(undoStack.size() - 1);
        lines.clear();
        lines.addAll(s.lines);
        caretLine = s.caretLine;
        caretCol = s.caretCol;
    }


    private int countLeadingSpaces(String s) {
        int i = 0;
        while (i < s.length() && s.charAt(i) == ' ') i++;
        return i;
    }

    private String makeIndent(int count) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < count; i++) sb.append(' ');
        return sb.toString();
    }

    private String rtrim(String s) {
        int i = s.length() - 1;
        while (i >= 0 && Character.isWhitespace(s.charAt(i))) i--;
        return s.substring(0, i + 1);
    }

    private void insertText(String s) {
        String line = lines.get(caretLine);
        line = line.substring(0, caretCol) + s + line.substring(caretCol);
        lines.set(caretLine, line);
        caretCol += s.length();
        recheckSyntax();
    }

    private void splitLineWithAutoIndent() {
        String line = lines.get(caretLine);
        String beforeCaret = line.substring(0, caretCol);
        String right = line.substring(caretCol);

        int baseIndent = countLeadingSpaces(line);
        boolean betweenBraces = beforeCaret.trim().endsWith("{") && right.trim().equals("}");

        if (betweenBraces) {
            int bracePos = beforeCaret.lastIndexOf('{');
            if (bracePos < 0) bracePos = caretCol - 1;

            String leftPart = line.substring(0, bracePos + 1);
            int totalBaseIndent = countLeadingSpaces(leftPart);

            String baseIndentStr = makeIndent(totalBaseIndent);
            String innerIndentStr = makeIndent(totalBaseIndent + 4);

            lines.set(caretLine, rtrim(leftPart));
            lines.add(caretLine + 1, innerIndentStr);
            lines.add(caretLine + 2, baseIndentStr + "}");

            caretLine++;
            caretCol = innerIndentStr.length();

            recheckSyntax();
            updateSuggestionsAuto();
            return;
        }

        String left = line.substring(0, caretCol);
        String rightRest = line.substring(caretCol);

        int extraIndent = 0;
        if (beforeCaret.contains("{")) {
            extraIndent = 4;
        }

        lines.set(caretLine, left);
        lines.add(caretLine + 1, rightRest);

        caretLine++;
        caretCol = 0;

        int totalIndent = baseIndent + extraIndent;
        if (totalIndent > 0) {
            String indent = makeIndent(totalIndent);
            insertText(indent);
        } else {
            recheckSyntax();
        }

        updateSuggestionsAuto();
    }

    private boolean autoPair(char chr) {
        String line = lines.get(caretLine);
        char next = (caretCol < line.length()) ? line.charAt(caretCol) : '\0';

        if (chr == '"') {
            insertText("\"\"");
            caretCol--;
            return true;
        }

        if (chr == '\'') {
            insertText("''");
            caretCol--;
            return true;
        }

        if (chr == '`') {
            insertText("``");
            caretCol--;
            return true;
        }

        if (chr == '(') {
            insertText("()");
            caretCol--;
            return true;
        }

        if (chr == '[') {
            insertText("[]");
            caretCol--;
            return true;
        }

        if (chr == '{') {
            insertText("{}");
            caretCol--;
            return true;
        }

        if ((chr == ')' && next == ')') ||
                (chr == ']' && next == ']') ||
                (chr == '}' && next == '}') ||
                (chr == '"' && next == '"') ||
                (chr == '\'' && next == '\'') ||
                (chr == '`' && next == '`')) {

            caretCol++;
            return true;
        }

        return false;
    }

    private void backspace() {
        if (caretCol > 0) {
            String line = lines.get(caretLine);
            line = line.substring(0, caretCol - 1) + line.substring(caretCol);
            lines.set(caretLine, line);
            caretCol--;
            recheckSyntax();
            updateSuggestionsAuto();
            return;
        }

        if (caretLine > 0) {
            int prevLen = lines.get(caretLine - 1).length();
            lines.set(caretLine - 1, lines.get(caretLine - 1) + lines.get(caretLine));
            lines.remove(caretLine);
            caretLine--;
            caretCol = prevLen;
            recheckSyntax();
            updateSuggestionsAuto();
        }
    }

    private void delete() {
        String line = lines.get(caretLine);
        if (caretCol < line.length()) {
            lines.set(caretLine, line.substring(0, caretCol) + line.substring(caretCol + 1));
            recheckSyntax();
            updateSuggestionsAuto();
        } else if (caretLine < lines.size() - 1) {
            lines.set(caretLine, line + lines.get(caretLine + 1));
            lines.remove(caretLine + 1);
            recheckSyntax();
            updateSuggestionsAuto();
        }
    }

    private void moveLeft() {
        if (caretCol > 0) caretCol--;
        else if (caretLine > 0) {
            caretLine--;
            caretCol = lines.get(caretLine).length();
        }
        suggestionOpen = false;
    }

    private void moveRight() {
        if (caretCol < lines.get(caretLine).length()) caretCol++;
        else if (caretLine < lines.size() - 1) {
            caretLine++;
            caretCol = 0;
        }
        suggestionOpen = false;
    }

    private void moveUp() {
        if (caretLine > 0) caretLine--;
        caretCol = Math.min(caretCol, lines.get(caretLine).length());
        suggestionOpen = false;
    }

    private void moveDown() {
        if (caretLine < lines.size() - 1) caretLine++;
        caretCol = Math.min(caretCol, lines.get(caretLine).length());
        suggestionOpen = false;
    }

    private void handleClosingBrace() {
        String line = lines.get(caretLine);
        int leading = countLeadingSpaces(line);

        if (caretCol > leading) {
            insertText("}");
            return;
        }

        int newIndent = Math.max(0, leading - 4);
        String indent = makeIndent(newIndent);

        lines.set(caretLine, indent + "}");
        caretCol = indent.length() + 1;
    }

    private void updateSuggestionsAuto() {
        String prefix = getCurrentTokenPrefix();
        if (prefix == null || prefix.isEmpty()) {
            suggestionOpen = false;
            return;
        }
        buildVisibleSuggestions(prefix);
        if (!visibleSuggestions.isEmpty()) {
            suggestionOpen = true;
            suggestionIndex = 0;
            updateSuggestionPopupPosition();
        } else {
            suggestionOpen = false;
        }
    }

    private String getCurrentTokenPrefix() {
        String line = lines.get(caretLine);
        int pos = Math.min(caretCol, line.length());

        int start = pos;
        while (start > 0) {
            char c = line.charAt(start - 1);
            if (Character.isLetterOrDigit(c) || c == '_' || c == '.') start--;
            else break;
        }
        if (start >= pos) return "";

        return line.substring(start, pos);
    }

    private int getCurrentTokenStartIndex() {
        String line = lines.get(caretLine);
        int pos = Math.min(caretCol, line.length());
        int start = pos;
        while (start > 0) {
            char c = line.charAt(start - 1);
            if (Character.isLetterOrDigit(c) || c == '_' || c == '.') start--;
            else break;
        }
        return start;
    }

    private void buildVisibleSuggestions(String prefix) {
        visibleSuggestions = new ArrayList<>();
        if (prefix == null) prefix = "";

        for (Suggestion s : allSuggestions) {
            if (s.name.startsWith(prefix)) {
                visibleSuggestions.add(s);
            }
        }
    }

    private void updateSuggestionPopupPosition() {
        String line = lines.get(caretLine);
        int x = editorX + 6 + field_22793.method_1727(
                line.substring(0, Math.min(caretCol, line.length()))
        );
        int y = editorY + caretLine * LINE_HEIGHT - scroll + LINE_HEIGHT;
        suggestionX = x;
        suggestionY = y;
    }

    private void acceptSuggestion() {
        if (!suggestionOpen || visibleSuggestions.isEmpty()) return;
        Suggestion s = visibleSuggestions.get(suggestionIndex);

        String line = lines.get(caretLine);
        int tokenStart = getCurrentTokenStartIndex();
        int tokenEnd = Math.min(caretCol, line.length());

        String newLine = line.substring(0, tokenStart) + s.name + line.substring(tokenEnd);
        lines.set(caretLine, newLine);
        caretCol = tokenStart + s.name.length();

        suggestionOpen = false;
        recheckSyntax();
    }

    private void recheckSyntax() {
        String code = collectText();

        Context cx = null;
        try {
            cx = Context.enter();
            cx.setLanguageVersion(Context.VERSION_ES6);
            cx.compileString(code, "<editor>", 1, null);

            lastErrorMessage = null;
            lastErrorLine = -1;
            lastErrorColumn = -1;

        } catch (EvaluatorException e) {
            lastErrorMessage = e.getMessage();
            lastErrorLine = e.lineNumber();
            lastErrorColumn = e.columnNumber();
        } catch (Throwable t) {
            lastErrorMessage = t.getMessage();
            lastErrorLine = -1;
            lastErrorColumn = -1;
        } finally {
            if (cx != null) Context.exit();
        }
    }

    @Override
    public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {
        ctx.method_25294(0, 0, field_22789, field_22790, 0xFF2B2B2B);

        int innerLeft   = editorX;
        int innerTop    = editorY;
        int innerRight  = editorX + editorW;
        int innerBottom = editorY + editorH;

        ctx.method_25294(innerLeft, innerTop, innerRight, innerBottom, 0xFF3C3F41);
        int gutterLeft = innerLeft - GUTTER_WIDTH;
        ctx.method_25294(gutterLeft, innerTop, innerLeft, innerBottom, 0xFF313335);

        int b = BORDER_SIZE;
        int col = 0xFF212223;

        ctx.method_25294(innerLeft - b, innerTop - b, innerRight + b, innerTop, col);           // top
        ctx.method_25294(innerLeft - b, innerBottom, innerRight + b, innerBottom + b, col);     // bottom
        ctx.method_25294(innerLeft - b, innerTop - b, innerLeft, innerBottom + b, col);         // left
        ctx.method_25294(innerRight, innerTop - b, innerRight + b, innerBottom + b, col);       // right

        int firstIndex = Math.max(0, scroll / LINE_HEIGHT - 1);
        int lastIndex  = Math.min(lines.size() - 1, (scroll + editorH) / LINE_HEIGHT + 1);

        for (int i = firstIndex; i <= lastIndex; i++) {
            int y = innerTop + i * LINE_HEIGHT - scroll;
            if (y + LINE_HEIGHT < innerTop || y > innerBottom) continue;

            ctx.method_51433(field_22793, String.valueOf(i + 1),
                    gutterLeft + 8, y, 0xFF808080, false);

            if (lastErrorLine == i + 1) {
                ctx.method_25294(gutterLeft + 2, y + 2, gutterLeft + 6, y + LINE_HEIGHT - 2, 0xFFCC3333);
            }
        }

        ctx.method_44379(innerLeft, innerTop, innerRight, innerBottom);

        for (int i = firstIndex; i <= lastIndex; i++) {
            int y = innerTop + i * LINE_HEIGHT - scroll;
            if (y + LINE_HEIGHT < innerTop || y > innerBottom) continue;

            String line = lines.get(i);

            int bgColor = 0xFF3C3F41;
            if (i == caretLine) {
                bgColor = 0xFF44484A;
            }
            if (lastErrorLine == i + 1) {
                bgColor = 0xFF553333;
            }

            ctx.method_25294(innerLeft, y, innerRight, y + LINE_HEIGHT, bgColor);

            drawSyntaxLine(ctx, line, innerLeft + 6, y);

            if (hasSelection() && isLineInSelection(i)) {
                int sx = getSelectionStartX(i);
                int ex = getSelectionEndX(i);
                ctx.method_25294(sx, y, ex, y + LINE_HEIGHT, 0x553A7AFE);
            }

            if (lastErrorLine == i + 1 && lastErrorColumn > 0) {
                int colIndex = Math.max(0, Math.min(line.length(), lastErrorColumn - 1));
                int errX = innerLeft + 6 + field_22793.method_1727(line.substring(0, colIndex));
                ctx.method_25294(errX, y, errX + 1, y + LINE_HEIGHT, 0xFFFF5555);
            }
        }

        drawCaret(ctx, innerLeft, innerTop, innerBottom);
        ctx.method_44380();

        if (suggestionOpen && !visibleSuggestions.isEmpty()) {
            renderSuggestionsPopup(ctx);
        }

        renderErrorPanel(ctx);
        super.method_25394(ctx, mouseX, mouseY, delta);
        drawMainBorder(ctx);
    }

    private void drawCaret(class_332 ctx, int innerLeft, int innerTop, int innerBottom) {
        String line = lines.get(caretLine);
        int caretX = innerLeft + 6 + field_22793.method_1727(
                line.substring(0, Math.min(caretCol, line.length()))
        );
        int caretY = innerTop + caretLine * LINE_HEIGHT - scroll;

        if (caretY + LINE_HEIGHT < innerTop || caretY > innerBottom) return;

        ctx.method_25294(caretX, caretY, caretX + 2, caretY + LINE_HEIGHT, 0xFFBBBBBB);
    }

    private void drawMainBorder(class_332 ctx) {
        int l = editorX;
        int t = editorY;
        int r = editorX + editorW;
        int btm = editorY + editorH;

        int bw = BORDER_SIZE;
        int col = 0xFF1F1F20;

        ctx.method_25294(l - bw, t - bw, r + bw, t, col);
        ctx.method_25294(l - bw, btm, r + bw, btm + bw, col);
        ctx.method_25294(l - bw, t - bw, l, btm + bw, col);
        ctx.method_25294(r, t - bw, r + bw, btm + bw, col);
    }

    private List<String> wrapText(String text, int maxWidthPx) {
        List<String> result = new ArrayList<>();
        if (text == null || text.isEmpty()) return result;

        String[] words = text.split(" ");
        StringBuilder current = new StringBuilder();

        for (String w : words) {
            if (current.length() == 0) {
                current.append(w);
            } else {
                String candidate = current + " " + w;
                if (field_22793.method_1727(candidate) <= maxWidthPx) {
                    current.append(" ").append(w);
                } else {
                    result.add(current.toString());
                    current.setLength(0);
                    current.append(w);
                }
            }
        }

        if (current.length() > 0) {
            result.add(current.toString());
        }

        return result;
    }

    private void renderSuggestionsPopup(class_332 ctx) {
        if (visibleSuggestions.isEmpty()) return;

        int maxItemsToShow = Math.min(8, visibleSuggestions.size());
        int maxLabelWidth = 0;
        for (int i = 0; i < maxItemsToShow; i++) {
            Suggestion s = visibleSuggestions.get(i);
            int w = field_22793.method_1727(s.name + "  " + s.signature);
            if (w > maxLabelWidth) maxLabelWidth = w;
        }

        Suggestion current = visibleSuggestions.get(suggestionIndex);
        String desc = current.description == null ? "" : current.description;

        int maxPopupWidth = Math.min(400, field_22789 - 20);
        int minPopupWidth = 120;

        int rawDescWidth = desc.isEmpty() ? 0 : field_22793.method_1727(desc);

        int popupW = Math.max(maxLabelWidth + 10, rawDescWidth + 10);
        popupW = Math.max(minPopupWidth, popupW);
        popupW = Math.min(maxPopupWidth, popupW);

        int descAreaWidth = popupW - 8;
        List<String> descLines = wrapText(desc, descAreaWidth);
        int descHeight = descLines.isEmpty() ? 0 : (descLines.size() * (LINE_HEIGHT - 2) + 6);

        int listHeight = maxItemsToShow * (LINE_HEIGHT + 1) + 8;
        int popupH = listHeight + (descHeight > 0 ? (descHeight + 6) : 0);

        int popupX = suggestionX;
        int popupY = suggestionY;

        if (popupX + popupW > field_22789 - 4) {
            popupX = Math.max(4, field_22789 - popupW - 4);
        }
        if (popupY + popupH > field_22790 - 4) {
            popupY = Math.max(4, popupY - popupH - LINE_HEIGHT);
        }

        ctx.method_25294(popupX, popupY, popupX + popupW, popupY + popupH, 0xEE3C3F41);
        ctx.method_25294(popupX, popupY, popupX + popupW, popupY + 1, 0xFF212223);
        ctx.method_25294(popupX, popupY + popupH - 1, popupX + popupW, popupY + popupH, 0xFF212223);
        ctx.method_25294(popupX, popupY, popupX + 1, popupY + popupH, 0xFF212223);
        ctx.method_25294(popupX + popupW - 1, popupY, popupX + popupW, popupY + popupH, 0xFF212223);

        int y = popupY + 4;
        for (int i = 0; i < maxItemsToShow; i++) {
            Suggestion s = visibleSuggestions.get(i);

            int bgCol = (i == suggestionIndex) ? 0x553A3D41 : 0x00000000;
            if (bgCol != 0) {
                ctx.method_25294(popupX + 2, y - 1, popupX + popupW - 2, y + LINE_HEIGHT + 1, bgCol);
            }

            int textX = popupX + 4;
            ctx.method_51433(field_22793, s.name, textX, y, 0xFFCCCCCC, false);
            int nameWidth = field_22793.method_1727(s.name);

            if (s.signature != null && !s.signature.isEmpty()) {
                ctx.method_51433(field_22793, "  " + s.signature,
                        textX + nameWidth, y, 0xFF808080, false);
            }

            y += LINE_HEIGHT + 1;
        }

        if (!descLines.isEmpty()) {
            int descY = popupY + listHeight + 2;
            ctx.method_25294(popupX + 2, descY - 2, popupX + popupW - 2, descY - 1, 0xFF212223);

            for (String line : descLines) {
                ctx.method_51433(field_22793, line, popupX + 4, descY, 0xFFBBBBBB, false);
                descY += (LINE_HEIGHT - 2);
            }
        }
    }

    private void renderErrorPanel(class_332 ctx) {
        if (lastErrorMessage == null) return;

        String msg = lastErrorMessage;
        if (msg.length() > 60) msg = msg.substring(0, 57) + "...";

        String text = "Syntax: " + msg;
        if (lastErrorLine > 0) {
            text += " (line " + lastErrorLine + ", col " + lastErrorColumn + ")";
        }

        int tw = field_22793.method_1727(text);
        int padding = 6;
        int x2 = field_22789 - 10;
        int y2 = field_22790 - 10;
        int x1 = x2 - tw - padding * 2;
        int y1 = y2 - LINE_HEIGHT - padding * 2;

        ctx.method_25294(x1, y1, x2, y2, 0xEE3C3F41);
        ctx.method_25294(x1, y1, x2, y1 + 1, 0xFFB00020);
        ctx.method_25294(x1, y2 - 1, x2, y2, 0xFFB00020);
        ctx.method_25294(x1, y1, x1 + 1, y2, 0xFFB00020);
        ctx.method_25294(x2 - 1, y1, x2, y2, 0xFFB00020);

        ctx.method_51433(field_22793, text, x1 + padding, y1 + padding, 0xFFFFCCCC, false);
    }

    private void drawSyntaxLine(class_332 ctx, String line, int x, int y) {
        String trimmed = line.trim();
        if (trimmed.startsWith("//")) {
            ctx.method_51433(field_22793, line, x, y, 0xFF808080, false);
            return;
        }

        List<String> tokens = tokenize(line);
        int xx = x;

        for (String t : tokens) {
            int color = 0xFFD0D0D0;

            if (KEYWORDS.contains(t)) {
                color = 0xFFCC7832;
            } else if (t.startsWith("\"") || t.startsWith("'")) {
                color = 0xFF6A8759;
            } else if (t.matches("[0-9]+")) {
                color = 0xFF6897BB;
            } else if (t.startsWith("//")) {
                color = 0xFF808080;
            } else if ("{}[]();,.".contains(t)) {
                color = 0xFFD0D0D0;
            }

            ctx.method_51433(field_22793, t, xx, y, color, false);
            xx += field_22793.method_1727(t);
        }
    }

    private boolean hasSelection() {
        return selStartLine != selEndLine || selStartCol != selEndCol;
    }

    private boolean isLineInSelection(int line) {
        int a = Math.min(selStartLine, selEndLine);
        int b = Math.max(selStartLine, selEndLine);
        return line >= a && line <= b;
    }

    private int getSelectionStartX(int line) {
        int col = (line == selStartLine) ? selStartCol : 0;
        return editorX + 6 + field_22793.method_1727(lines.get(line).substring(0, col));
    }

    private int getSelectionEndX(int line) {
        int col = (line == selEndLine) ? selEndCol : lines.get(line).length();
        return editorX + 6 + field_22793.method_1727(lines.get(line).substring(0, col));
    }

    private List<String> tokenize(String line) {
        List<String> result = new ArrayList<>();
        StringBuilder current = new StringBuilder();

        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);

            if ("{}[]();, .".indexOf(c) >= 0) {
                if (current.length() > 0) {
                    result.add(current.toString());
                    current.setLength(0);
                }
                result.add(String.valueOf(c));
            } else {
                current.append(c);
            }
        }

        if (current.length() > 0) {
            result.add(current.toString());
        }

        return result;
    }
}
