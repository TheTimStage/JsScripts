package org.tts.jsscripts.commands;

import com.mojang.brigadier.CommandDispatcher;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import org.tts.jsscripts.networking.JsSNetworking;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_7157;

public class JsSCommand {

    public static void init() {
        CommandRegistrationCallback.EVENT.register(JsSCommand::register);
    }

    private static void register(CommandDispatcher<class_2168> dispatcher,
                                 class_7157 registryAccess,
                                 class_2170.class_5364 env) {

        dispatcher.register(
                class_2170.method_9247("jsscripts")
                        .requires(src -> src.method_9259(2))
                        .then(class_2170.method_9247("gui")
                                .executes(ctx -> {

                                    if (!(ctx.getSource().method_9228() instanceof class_3222 player)) {
                                        ctx.getSource().method_9226(
                                                () -> class_2561.method_43470("Only players can use this."),
                                                false
                                        );
                                        return 0;
                                    }

                                    // отправляем пакет открытия меню
                                    ServerPlayNetworking.send(player, new JsSNetworking.OpenMenu(""));

                                    return 1;
                                }))
        );
    }
}
