package org.tts.jsscripts.systems;

import net.minecraft.class_3222;

public class ScriptRunEvent {
    public final String name;
    public final class_3222 player;

    public ScriptRunEvent(String name, class_3222 player) {
        this.name = name;
        this.player = player;
    }


}
