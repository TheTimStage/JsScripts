package org.tts.jsscripts.systems;

import net.fabricmc.fabric.api.event.lifecycle.v1.*;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.class_1269;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;

public final class ScriptAPI {

    private static MinecraftServer server;

    public static void init(MinecraftServer srv) {
        server = srv;

        ScriptEngine.init(server);
        registerEvents();

        System.out.println("[JsScripts] Script API loaded with extended events.");
    }

    private static void registerEvents() {
        ServerLifecycleEvents.SERVER_STARTED.register(s ->
                ScriptEngine.emit("serverStart")
        );

        ServerTickEvents.END_SERVER_TICK.register(s -> {

            ScriptEngine.emit("serverTick");
            for (class_3222 p : s.method_3760().method_14571()) {
                ScriptEngine.emit("playerTick", p);
            }
        });

        ServerPlayConnectionEvents.JOIN.register((handler, sender, srv2) ->
                ScriptEngine.emit("playerJoin", handler.field_14140)
        );

        ServerPlayConnectionEvents.DISCONNECT.register((handler, srv2) ->
                ScriptEngine.emit("playerLeave", handler.field_14140)
        );

        ServerMessageEvents.CHAT_MESSAGE.register((message, sender, params) ->
                ScriptEngine.emit("chat",
                        message.method_44862(),
                        sender)
        );

        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
            if (!world.method_8608())
                ScriptEngine.emit("blockBreak", player, pos, state);
        });

        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (!world.method_8608()) {
                ScriptEngine.emit("blockPlace",
                        player,
                        hit.method_17777(),
                        world.method_8320(hit.method_17777()));
            }
            return class_1269.field_5811;
        });
    }
}
