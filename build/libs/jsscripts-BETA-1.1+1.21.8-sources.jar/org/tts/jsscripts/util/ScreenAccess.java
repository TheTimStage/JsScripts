package org.tts.jsscripts.util;

import javax.swing.text.Element;
import net.minecraft.class_4068;
import net.minecraft.class_6379;

public interface ScreenAccess {

    <T extends Element & class_4068 & class_6379> T js_addDrawable(T element);

    <T extends net.minecraft.class_364 & class_4068 & class_6379> T js_addDrawable(T element);
}
