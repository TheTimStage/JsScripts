package org.tts.jsscripts.networking;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import org.tts.jsscripts.JsScripts;

import java.util.ArrayList;
import java.util.List;

public final class JsSNetworking {
    private JsSNetworking() {}
    public record ScriptEntry(String path, boolean directory) {}

    public static final class_9139<class_9129, ScriptEntry> SCRIPT_ENTRY_CODEC =
            class_9139.method_56435(
                    class_9135.field_48554, ScriptEntry::path,
                    class_9135.field_48547, ScriptEntry::directory,
                    ScriptEntry::new
            );
    public record OpenMenu(String directory) implements class_8710 {
        public static final class_2960 ID_RAW = class_2960.method_60655(JsScripts.MOD_ID, "open_menu");
        public static final class_9154<OpenMenu> ID = new class_9154<>(ID_RAW);
        public static final class_9139<class_9129, OpenMenu> CODEC =
                class_9139.method_56434(class_9135.field_48554, OpenMenu::directory, OpenMenu::new);

        @Override public class_9154<? extends class_8710> method_56479() { return ID; }
    }

    public record OpenEditor(String path, String code) implements class_8710 {
        public static final class_2960 ID_RAW = class_2960.method_60655(JsScripts.MOD_ID, "open_editor");
        public static final class_9154<OpenEditor> ID = new class_9154<>(ID_RAW);
        public static final class_9139<class_9129, OpenEditor> CODEC =
                class_9139.method_56435(
                        class_9135.field_48554, OpenEditor::path,
                        class_9135.field_48554, OpenEditor::code,
                        OpenEditor::new
                );

        @Override public class_9154<? extends class_8710> method_56479() { return ID; }
    }

    public record ScriptsList(String directory, List<ScriptEntry> entries) implements class_8710 {
        public static final class_2960 ID_RAW = class_2960.method_60655(JsScripts.MOD_ID, "scripts_list");
        public static final class_9154<ScriptsList> ID = new class_9154<>(ID_RAW);
        public static final class_9139<class_9129, ScriptsList> CODEC =
                class_9139.method_56435(
                        class_9135.field_48554, ScriptsList::directory,
                        class_9135.method_56376(ArrayList::new, SCRIPT_ENTRY_CODEC), ScriptsList::entries,
                        ScriptsList::new
                );

        @Override public class_9154<? extends class_8710> method_56479() { return ID; }
    }

    public record CreateScript(String name) implements class_8710 {
        public static final class_2960 ID_RAW = class_2960.method_60655(JsScripts.MOD_ID, "create_script");
        public static final class_9154<CreateScript> ID = new class_9154<>(ID_RAW);
        public static final class_9139<class_9129, CreateScript> CODEC =
                class_9139.method_56434(class_9135.field_48554, CreateScript::name, CreateScript::new);

        @Override public class_9154<? extends class_8710> method_56479() { return ID; }
    }
    

    public record SaveScript(String path, String code) implements class_8710 {
        public static final class_2960 ID_RAW = class_2960.method_60655(JsScripts.MOD_ID, "save_script");
        public static final class_9154<SaveScript> ID = new class_9154<>(ID_RAW);
        public static final class_9139<class_9129, SaveScript> CODEC =
                class_9139.method_56435(
                        class_9135.field_48554, SaveScript::path,
                        class_9135.field_48554, SaveScript::code,
                        SaveScript::new
                );
        @Override public class_9154<? extends class_8710> method_56479() { return ID; }
    }

    public record DeleteEntry(String path, boolean directory) implements class_8710 {
        public static final class_2960 ID_RAW = class_2960.method_60655(JsScripts.MOD_ID, "delete_entry");
        public static final class_9154<DeleteEntry> ID = new class_9154<>(ID_RAW);
        public static final class_9139<class_9129, DeleteEntry> CODEC =
                class_9139.method_56435(
                        class_9135.field_48554, DeleteEntry::path,
                        class_9135.field_48547, DeleteEntry::directory,
                        DeleteEntry::new
                );
        @Override public class_9154<? extends class_8710> method_56479() { return ID; }
    }

    public record RunScript(String path) implements class_8710 {
        public static final class_2960 ID_RAW = class_2960.method_60655(JsScripts.MOD_ID, "run_script");
        public static final class_9154<RunScript> ID = new class_9154<>(ID_RAW);
        public static final class_9139<class_9129, RunScript> CODEC =
                class_9139.method_56434(class_9135.field_48554, RunScript::path, RunScript::new);

        @Override public class_9154<? extends class_8710> method_56479() { return ID; }
    }

    public record OpenEditorRequest(String path) implements class_8710 {
        public static final class_2960 ID_RAW = class_2960.method_60655(JsScripts.MOD_ID, "request_open_editor");
        public static final class_9154<OpenEditorRequest> ID = new class_9154<>(ID_RAW);
        public static final class_9139<class_9129, OpenEditorRequest> CODEC =
                class_9139.method_56434(class_9135.field_48554, OpenEditorRequest::path, OpenEditorRequest::new);

        @Override public class_9154<? extends class_8710> method_56479() { return ID; }
    }

    public record RequestList(String directory) implements class_8710 {
        public static final class_2960 ID_RAW = class_2960.method_60655(JsScripts.MOD_ID, "request_list");
        public static final class_9154<RequestList> ID = new class_9154<>(ID_RAW);
        public static final class_9139<class_9129, RequestList> CODEC =
                class_9139.method_56434(class_9135.field_48554, RequestList::directory, RequestList::new);

        @Override public class_9154<? extends class_8710> method_56479() { return ID; }
    }

    public record ScriptStarted(String path) implements class_8710 {
        public static final class_2960 ID_RAW =
                class_2960.method_60655(JsScripts.MOD_ID, "script_started");
        public static final class_9154<ScriptStarted> ID = new class_9154<>(ID_RAW);

        public static final class_9139<class_9129, ScriptStarted> CODEC =
                class_9139.method_56434(class_9135.field_48554, ScriptStarted::path, ScriptStarted::new);

        @Override public class_9154<? extends class_8710> method_56479() { return ID; }
    }

    public record ScriptStopped(String path) implements class_8710 {
        public static final class_2960 ID_RAW =
                class_2960.method_60655(JsScripts.MOD_ID, "script_stopped");
        public static final class_9154<ScriptStopped> ID = new class_9154<>(ID_RAW);

        public static final class_9139<class_9129, ScriptStopped> CODEC =
                class_9139.method_56434(class_9135.field_48554, ScriptStopped::path, ScriptStopped::new);

        @Override public class_9154<? extends class_8710> method_56479() { return ID; }
    }

    public record StopScript(String path) implements class_8710 {
        public static final class_2960 ID_RAW =
                class_2960.method_60655(JsScripts.MOD_ID, "stop_script");
        public static final class_9154<StopScript> ID = new class_9154<>(ID_RAW);

        public static final class_9139<class_9129, StopScript> CODEC =
                class_9139.method_56434(
                        class_9135.field_48554, StopScript::path,
                        StopScript::new
                );

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return ID;
        }
    }



    private static void sendToServer(class_8710 payload) {
        ClientPlayNetworking.send(payload);
    }

    public static void sendRun(String path) {
        sendToServer(new RunScript(path));
    }

    public static void sendEdit(String path) {
        sendToServer(new OpenEditorRequest(path));
    }

    public static void sendDelete(String path, boolean directory) {
        sendToServer(new DeleteEntry(path, directory));
    }

    public static void sendSaveScript(String path, String code) {
        sendToServer(new SaveScript(path, code));
    }

    public static void sendRequestList(String directory) {
        sendToServer(new RequestList(directory));
    }


    public static void registerPayloadTypes() {
        PayloadTypeRegistry.playS2C().register(OpenMenu.ID, OpenMenu.CODEC);
        PayloadTypeRegistry.playS2C().register(OpenEditor.ID, OpenEditor.CODEC);
        PayloadTypeRegistry.playS2C().register(ScriptsList.ID, ScriptsList.CODEC);
        PayloadTypeRegistry.playC2S().register(SaveScript.ID, SaveScript.CODEC);
        PayloadTypeRegistry.playC2S().register(DeleteEntry.ID, DeleteEntry.CODEC);
        PayloadTypeRegistry.playC2S().register(RunScript.ID, RunScript.CODEC);
        PayloadTypeRegistry.playC2S().register(OpenEditorRequest.ID, OpenEditorRequest.CODEC);
        PayloadTypeRegistry.playC2S().register(RequestList.ID, RequestList.CODEC);
        PayloadTypeRegistry.playC2S().register(CreateScript.ID, CreateScript.CODEC);
        PayloadTypeRegistry.playS2C().register(JsSNetworking.ScriptStarted.ID, JsSNetworking.ScriptStarted.CODEC);
        PayloadTypeRegistry.playS2C().register(JsSNetworking.ScriptStopped.ID, JsSNetworking.ScriptStopped.CODEC);
        PayloadTypeRegistry.playC2S().register(StopScript.ID, StopScript.CODEC);
    }

}
