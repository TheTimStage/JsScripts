package org.tts.jsscripts.networking;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_310;
import org.tts.jsscripts.client.JsSEditorScreen;
import org.tts.jsscripts.client.ScriptsScreen;

import java.util.HashSet;
import java.util.Set;

public final class JsSNetworkingClient {
    private static final Set<String> RUNNING = new HashSet<>();

    private JsSNetworkingClient() {}

    public static void registerReceivers() {
        ClientPlayNetworking.registerGlobalReceiver(JsSNetworking.OpenMenu.ID,
                (payload, ctx) -> class_310.method_1551()
                        .execute(() -> class_310.method_1551()
                                .method_1507(new ScriptsScreen(payload.directory()))));

        ClientPlayNetworking.registerGlobalReceiver(JsSNetworking.ScriptsList.ID, (payload, context) -> {
            class_310 client = class_310.method_1551();

            client.execute(() -> {
                if (client.field_1755 instanceof ScriptsScreen screen) {
                    screen.updateEntries(payload.directory(), payload.entries());
                }
            });
        });

        ClientPlayNetworking.registerGlobalReceiver(JsSNetworking.OpenEditor.ID,
                (payload, ctx) -> class_310.method_1551()
                        .execute(() -> class_310.method_1551()
                                .method_1507(new JsSEditorScreen(payload.path(), payload.code()))));

        ClientPlayNetworking.registerGlobalReceiver(
                JsSNetworking.ScriptStarted.ID,
                (payload, ctx) -> class_310.method_1551().execute(() ->
                        RUNNING.add(payload.path()))
        );

        ClientPlayNetworking.registerGlobalReceiver(
                JsSNetworking.ScriptStopped.ID,
                (payload, ctx) -> class_310.method_1551().execute(() ->
                        RUNNING.remove(payload.path()))
        );

        ClientPlayNetworking.registerGlobalReceiver(
                JsSNetworking.ScriptStarted.ID,
                (payload, ctx) -> class_310.method_1551().execute(() -> {
                    RUNNING.add(payload.path());

                    if (class_310.method_1551().field_1755 instanceof ScriptsScreen) {
                        class_310.method_1551().method_1507(null);
                    }
                })
        );



    }

    public static void sendRequestList(String dir) {
        ClientPlayNetworking.send(new JsSNetworking.RequestList(dir));
    }

    public static void sendSaveScript(String path, String code) {
        ClientPlayNetworking.send(new JsSNetworking.SaveScript(path, code));
    }

    public static void sendDeleteEntry(String path, boolean directory) {
        ClientPlayNetworking.send(new JsSNetworking.DeleteEntry(path, directory));
    }

    public static void sendRunScript(String path) {
        ClientPlayNetworking.send(new JsSNetworking.RunScript(path));
    }

    public static void sendOpenEditor(String path) {
        ClientPlayNetworking.send(new JsSNetworking.OpenEditorRequest(path));
    }

    public static void sendStopScript(String path) {
        ClientPlayNetworking.send(new JsSNetworking.StopScript(path));
    }


    public static boolean isRunning(String path) {
        return RUNNING.contains(path);
    }
}
